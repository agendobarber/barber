(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_688c1cf4._.js",
  "static/chunks/node_modules_0dbd987f._.js"
],
    source: "dynamic"
});
