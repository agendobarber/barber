(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_23d15d40._.js",
  "static/chunks/node_modules_next_8918cfbb._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_date-fns_cd6a2c0c._.js",
  "static/chunks/node_modules_zod_v4_89a8de31._.js",
  "static/chunks/node_modules_bf96ff47._.js"
],
    source: "dynamic"
});
