(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_d402edc1._.js",
  "static/chunks/node_modules_4f160ce0._.js"
],
    source: "dynamic"
});
