var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/signup/route.js")
R.c("server/chunks/node_modules_7816c582._.js")
R.c("server/chunks/[root-of-the-server]__4aa3a050._.js")
R.m("[project]/.next-internal/server/app/api/signup/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/signup/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/signup/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
