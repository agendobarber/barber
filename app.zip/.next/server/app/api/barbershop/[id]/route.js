var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/barbershop/[id]/route.js")
R.c("server/chunks/node_modules_next_896ad123._.js")
R.c("server/chunks/[root-of-the-server]__4148da07._.js")
R.m("[project]/.next-internal/server/app/api/barbershop/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/barbershop/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/barbershop/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
