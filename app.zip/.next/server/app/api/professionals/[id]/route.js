var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/professionals/[id]/route.js")
R.c("server/chunks/node_modules_next_e4683636._.js")
R.c("server/chunks/[root-of-the-server]__d015cb04._.js")
R.m("[project]/.next-internal/server/app/api/professionals/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/professionals/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/professionals/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
