-- AlterTable
ALTER TABLE "public"."Booking" ADD COLUMN     "status" INTEGER NOT NULL DEFAULT 1;
