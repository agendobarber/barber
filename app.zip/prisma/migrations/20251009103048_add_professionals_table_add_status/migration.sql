-- AlterTable
ALTER TABLE "public"."Professional" ADD COLUMN     "status" INTEGER NOT NULL DEFAULT 1;
