-- AlterTable
ALTER TABLE "public"."BarbershopService" ADD COLUMN     "tempo" INTEGER NOT NULL DEFAULT 0;
