/*
  Warnings:

  - You are about to drop the column `imageUrl` on the `BarbershopService` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "public"."BarbershopService" DROP COLUMN "imageUrl";
