-- AlterTable
ALTER TABLE "public"."BarbershopService" ADD COLUMN     "status" INTEGER NOT NULL DEFAULT 1;
