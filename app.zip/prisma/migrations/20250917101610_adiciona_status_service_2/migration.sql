-- AlterTable
ALTER TABLE "public"."BarbershopService" ALTER COLUMN "status" SET DEFAULT 1;
